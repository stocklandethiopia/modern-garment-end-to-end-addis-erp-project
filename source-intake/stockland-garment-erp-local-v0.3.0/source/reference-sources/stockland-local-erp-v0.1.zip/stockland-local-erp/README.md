# Stockland Local Reference Runtime (stand-in)

**What it is:** a dependency-free (Python ≥3.10, SQLite) executable specification of the v0.7 19-stage garment route controls, with a one-command installer and tests.
**What it is not:** the canonical Angular 22 / Laravel 13 / PostgreSQL 18 source, a production system, or a complete ERP. Tenant scoping is in code, not database RLS.

    python3 install.py --reset     # preflight, DB, 16 tests, 19-stage demo, VERIFICATION_REPORT.md
    python3 -m unittest discover -s tests -t .

## Replacement map (port each test to a PHPUnit/PostgreSQL feature test, then delete the stand-in)
| Stand-in function | Package | Production target |
|---|---|---|
| create_style / verify_material / release_style | WP-05 / WP-07 | existing BOM + tech-pack services; real material master |
| receive_lot / dispose_lot / issue / return_material / reverse_entry | WP-07 | WMS posting service; append-only ledger tables with RLS |
| approve_marker / cut_bundles | WP-06 / WP-09 | marker/cut-order + bundle services |
| inspect / reinspect / record_work | WP-09 / WP-11 | MES scan-event + quality inspection services |
| pack / set_plan / approve_plan / final_audit | WP-11 / WP-12 | pack + buyer-profile (effective-dated) + audit services |
| receive_fg + outbox | WP-12 / WP-13 | exactly-once FG receipt, transactional outbox to finance |
| advance + GUARDS | WP-08 | route/state-machine service |

## Left out (next slices)
Bundle split/merge/marriage, reservations, costing/GL, HTTP API + Angular UI, buyer profile library, subcontract custody, POS/retail and distribution-centre flows.
