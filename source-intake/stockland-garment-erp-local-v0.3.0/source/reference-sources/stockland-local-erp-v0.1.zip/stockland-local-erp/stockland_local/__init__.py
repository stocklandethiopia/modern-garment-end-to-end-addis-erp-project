"""Stockland LOCAL REFERENCE RUNTIME (stdlib only). Not the canonical Laravel/Angular/PG source."""
