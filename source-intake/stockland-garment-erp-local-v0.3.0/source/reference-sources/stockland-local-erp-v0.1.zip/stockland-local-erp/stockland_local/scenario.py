"""Seed data + a scripted path through all 19 stages. Fixture numbers are TEST FIXTURES, not buyer standards."""
import json
from . import engine as E
ON = "2026-11-24"

def setup(c, t, required=(12,)):
    E.add_tenant(c, t)
    E.create_style(c, t, "TEE-100", 1, [("JERSEY", "FABRIC", 1.2), ("BTN", "TRIM", 6), ("WASH", "CHEMICAL", 0.05), ("POLY", "PACKAGING", 1)], "designer")
    for m in ("JERSEY", "BTN", "WASH", "POLY"): E.verify_material(c, t, "TEE-100", 1, m, "wp07_stub")  # WP-07 stand-in
    E.release_style(c, t, "TEE-100", 1, "approver")
    for m, l, q, kw in (("JERSEY", "F1", 500, {}), ("BTN", "T1", 700, {}), ("WASH", "C1", 10, {"expiry": "2027-06-30", "sds": True}), ("POLY", "P1", 120, {})):
        E.receive_lot(c, t, m, l, q, **kw); E.dispose_lot(c, t, m, l, "ACCEPTED", "qc")
    E.create_order(c, t, "ORD-1", "TEE-100", 1, {("S", "BLK"): 30, ("M", "BLK"): 70}, "BUYER-X", required)

def step(c, t, n, o="ORD-1"):
    req = json.loads(E._order(c, t, o)["required"])
    if n == 5: E.issue(c, t, o, "FABRIC", "JERSEY", "F1", 120, "store", ON)
    elif n == 6: E.approve_marker(c, t, o, "sha256:demo-marker", "pattern")
    elif n == 7: E.cut_bundles(c, t, o, [("B1", "S", "BLK", 30), ("B2", "M", "BLK", 40), ("B3", "M", "BLK", 30)], "cutter")
    elif n == 9: E.issue(c, t, o, "TRIM", "BTN", "T1", 600, "store", ON)
    elif n == 10 and 10 in req: E.record_work(c, t, o, 10, "embellishment", "print")
    elif n == 11: E.record_work(c, t, o, 11, "sewing complete", "sewing")
    elif n == 12 and 12 in req: E.issue(c, t, o, "CHEMICAL", "WASH", "C1", 5, "store", ON); E.record_work(c, t, o, 12, "garment wash", "wet")
    elif n == 13:
        E.inspect(c, t, "B1", 30, 0, 0, "k-b1", "qa1"); E.inspect(c, t, "B2", 38, 2, 0, "k-b2", "qa1"); E.inspect(c, t, "B3", 29, 0, 1, "k-b3", "qa1")
    elif n == 14: E.reinspect(c, t, "B2", 2, 0, 0, "k-b2r", "qa2")
    elif n == 15: E.record_work(c, t, o, 15, "pressed", "finishing")
    elif n == 16:
        E.issue(c, t, o, "PACKAGING", "POLY", "P1", 100, "store", ON); E.pack(c, t, o, "CTN1", [("S", "BLK", 30), ("M", "BLK", 69)], "pk-1", "packer")
    elif n == 17:
        E.set_plan(c, t, "BUYER-X", 1, 50, 150, 13, 1, 2, "planner"); E.approve_plan(c, t, "BUYER-X", 1, "approver"); E.final_audit(c, t, o, 1, "auditor")
    elif n == 18: E.receive_fg(c, t, o, "fg-1", "warehouse")
    elif n == 19: E.record_work(c, t, o, 19, "DC receipt + feedback", "dc")

def drive(c, t, upto, o="ORD-1"):
    while E._order(c, t, o)["stage"] < upto:
        n = E._order(c, t, o)["stage"] + 1; step(c, t, n, o); E.advance(c, t, o, "planner")
