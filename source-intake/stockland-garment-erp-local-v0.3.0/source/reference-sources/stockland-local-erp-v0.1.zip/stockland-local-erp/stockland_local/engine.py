"""LOCAL REFERENCE RUNTIME: executable acceptance spec for the v0.7 19-stage route controls (WP-06..WP-15 behaviours).
NOT production, NOT the canonical Angular/Laravel/PostgreSQL source. Tenant scoping is in code, NOT database RLS."""
import sqlite3, json, hashlib, datetime as dt

class Reject(Exception):
    def __init__(self, code, msg=""):
        super().__init__(f"{code}: {msg}" if msg else code); self.code = code

STAGES = {1:("Production demand and order definition",0),2:("Technical readiness",0),3:("Supplier and material receiving",0),
 4:("Material planning and allocation",0),5:("Fabric roll issue and relaxation",0),6:("Marker and pattern control",0),
 7:("Spreading, cutting, lay reconciliation",0),8:("Bundle and component identity",0),9:("Separate trim/accessory issue",0),
 10:("Print/embroidery/embellishment",1),11:("Sewing/assembly",0),12:("Washing/dyeing/special processing",1),
 13:("Quality at source and end-line",0),14:("Rework and CAPA",0),15:("Finishing and pressing",0),
 16:("Packing and cartonization",0),17:("Final random audit",0),18:("Finished-goods receipt",0),19:("Warehouse and customer feedback",0)}
LEDGER_MIN = {"FABRIC":4,"TRIM":8,"CHEMICAL":11,"PACKAGING":15}  # stages that must be complete before each ledger may post

SCHEMA = """
CREATE TABLE tenants(id TEXT PRIMARY KEY);
CREATE TABLE styles(tenant TEXT,style TEXT,rev INT,status TEXT NOT NULL DEFAULT 'DRAFT' CHECK(status IN('DRAFT','RELEASED')),created_by TEXT NOT NULL,released_by TEXT,PRIMARY KEY(tenant,style,rev),FOREIGN KEY(tenant) REFERENCES tenants(id));
CREATE TABLE bom(tenant TEXT,style TEXT,rev INT,material TEXT,ctype TEXT CHECK(ctype IN('FABRIC','TRIM','CHEMICAL','PACKAGING')),per_unit REAL CHECK(per_unit>0),verified INT NOT NULL DEFAULT 0,PRIMARY KEY(tenant,style,rev,material),FOREIGN KEY(tenant,style,rev) REFERENCES styles);
CREATE TABLE lots(tenant TEXT,material TEXT,lot TEXT,qty REAL CHECK(qty>0),status TEXT NOT NULL DEFAULT 'QUARANTINE' CHECK(status IN('QUARANTINE','ACCEPTED','REJECTED')),expiry TEXT,sds INT NOT NULL DEFAULT 0,PRIMARY KEY(tenant,material,lot));
CREATE TABLE orders(tenant TEXT,id TEXT,style TEXT,rev INT,buyer TEXT,required TEXT NOT NULL,stage INT NOT NULL DEFAULT 0,marker TEXT,PRIMARY KEY(tenant,id),FOREIGN KEY(tenant,style,rev) REFERENCES styles);
CREATE TABLE order_lines(tenant TEXT,ord TEXT,size TEXT,colour TEXT,qty INT CHECK(qty>0),PRIMARY KEY(tenant,ord,size,colour),FOREIGN KEY(tenant,ord) REFERENCES orders);
CREATE TABLE ledger(id INTEGER PRIMARY KEY AUTOINCREMENT,tenant TEXT NOT NULL,ledger TEXT NOT NULL,ord TEXT NOT NULL,material TEXT NOT NULL,lot TEXT NOT NULL,delta REAL NOT NULL,kind TEXT NOT NULL CHECK(kind IN('ISSUE','RETURN','REVERSAL')),reverses INT UNIQUE,reason TEXT,actor TEXT NOT NULL,FOREIGN KEY(tenant,ord) REFERENCES orders,FOREIGN KEY(tenant,material,lot) REFERENCES lots);
CREATE TABLE bundles(tenant TEXT,id TEXT,ord TEXT,size TEXT,colour TEXT,qty INT CHECK(qty>0),good INT NOT NULL DEFAULT 0,rework INT NOT NULL DEFAULT 0,reject INT NOT NULL DEFAULT 0,inspected INT NOT NULL DEFAULT 0,inspector TEXT,PRIMARY KEY(tenant,id),FOREIGN KEY(tenant,ord) REFERENCES orders);
CREATE TABLE scans(tenant TEXT,key TEXT,fp TEXT,result TEXT,PRIMARY KEY(tenant,key));
CREATE TABLE cartons(tenant TEXT,id TEXT,ord TEXT,size TEXT,colour TEXT,qty INT CHECK(qty>0),PRIMARY KEY(tenant,id,size,colour),FOREIGN KEY(tenant,ord) REFERENCES orders);
CREATE TABLE plans(tenant TEXT,buyer TEXT,ver INT,lot_min INT,lot_max INT,sample INT,ac INT,re INT,created_by TEXT NOT NULL,approved_by TEXT,PRIMARY KEY(tenant,buyer,ver));
CREATE TABLE audits(tenant TEXT,ord TEXT,ver INT,lot INT,sample INT,defects INT,result TEXT,actor TEXT,PRIMARY KEY(tenant,ord));
CREATE TABLE fg_receipts(tenant TEXT,ord TEXT,qty INT,actor TEXT,PRIMARY KEY(tenant,ord));
CREATE TABLE outbox(tenant TEXT,dedupe TEXT,topic TEXT,payload TEXT,PRIMARY KEY(tenant,dedupe));
CREATE TABLE events(id INTEGER PRIMARY KEY AUTOINCREMENT,tenant TEXT,ord TEXT,kind TEXT,detail TEXT,actor TEXT);
CREATE TRIGGER ledger_u BEFORE UPDATE ON ledger BEGIN SELECT RAISE(ABORT,'ledger is append-only'); END;
CREATE TRIGGER ledger_d BEFORE DELETE ON ledger BEGIN SELECT RAISE(ABORT,'ledger is append-only'); END;
CREATE TRIGGER events_u BEFORE UPDATE ON events BEGIN SELECT RAISE(ABORT,'events are append-only'); END;
CREATE TRIGGER events_d BEFORE DELETE ON events BEGIN SELECT RAISE(ABORT,'events are append-only'); END;
"""

def connect(path=":memory:"):
    c = sqlite3.connect(path); c.row_factory = sqlite3.Row; c.execute("PRAGMA foreign_keys=ON")
    if not c.execute("SELECT 1 FROM sqlite_master WHERE name='tenants'").fetchone(): c.executescript(SCHEMA)
    return c

def tx(f):
    def w(c, *a, **k):
        with c: return f(c, *a, **k)   # any Reject/exception rolls the whole command back
    w.__name__ = f.__name__; return w

def _one(c, sql, *a): return c.execute(sql, a).fetchone()
def _ev(c, t, o, k, d, a): c.execute("INSERT INTO events(tenant,ord,kind,detail,actor) VALUES(?,?,?,?,?)", (t, o, k, json.dumps(d, sort_keys=True), a))
def _order(c, t, o):
    r = _one(c, "SELECT * FROM orders WHERE tenant=? AND id=?", t, o)
    if not r: raise Reject("NOT_FOUND", f"order {o}")
    return r
def _bundle(c, t, b):
    r = _one(c, "SELECT * FROM bundles WHERE tenant=? AND id=?", t, b)
    if not r: raise Reject("NOT_FOUND", f"bundle {b}")
    return r
def _need(o, n):
    if o["stage"] < n: raise Reject("ROUTE", f"stage {n} must be complete; order is at {o['stage']}")
def _total(c, t, o): return _one(c, "SELECT COALESCE(SUM(qty),0) FROM order_lines WHERE tenant=? AND ord=?", t, o)[0]
def _net(c, t, o, ledger, material=None):
    q, a = "SELECT COALESCE(SUM(delta),0) FROM ledger WHERE tenant=? AND ord=? AND ledger=?", [t, o, ledger]
    if material: q += " AND material=?"; a.append(material)
    return c.execute(q, a).fetchone()[0]
def _bal(c, t, m, lot):
    return _one(c, "SELECT (SELECT qty FROM lots WHERE tenant=? AND material=? AND lot=?)-COALESCE((SELECT SUM(delta) FROM ledger WHERE tenant=? AND material=? AND lot=?),0)", t, m, lot, t, m, lot)[0]
def _fp(*a): return hashlib.sha256(json.dumps(a, sort_keys=True, default=str).encode()).hexdigest()
def _idem(c, t, key, fp):
    r = _one(c, "SELECT fp,result FROM scans WHERE tenant=? AND key=?", t, key)
    if r:
        if r["fp"] != fp: raise Reject("KEY_REUSE", key)
        return {**json.loads(r["result"]), "replayed": True}
def _done(c, t, key, fp, res): c.execute("INSERT INTO scans VALUES(?,?,?,?)", (t, key, fp, json.dumps(res))); return res

# ---- WP-05/06/07 stand-ins: style, BOM, release gate, lots ----
@tx
def add_tenant(c, t): c.execute("INSERT OR IGNORE INTO tenants VALUES(?)", (t,))

@tx
def create_style(c, t, style, rev, lines, actor):
    try:
        c.execute("INSERT INTO styles(tenant,style,rev,created_by) VALUES(?,?,?,?)", (t, style, rev, actor))
        for m, ct, q in lines: c.execute("INSERT INTO bom(tenant,style,rev,material,ctype,per_unit) VALUES(?,?,?,?,?,?)", (t, style, rev, m, ct, q))
    except sqlite3.IntegrityError as e: raise Reject("INVALID", str(e))

@tx
def verify_material(c, t, style, rev, material, actor):  # TEST SCAFFOLD standing in for WP-07 material approval
    c.execute("UPDATE bom SET verified=1 WHERE tenant=? AND style=? AND rev=? AND material=?", (t, style, rev, material))

@tx
def release_style(c, t, style, rev, actor):
    s = _one(c, "SELECT * FROM styles WHERE tenant=? AND style=? AND rev=?", t, style, rev)
    if not s: raise Reject("NOT_FOUND", "style revision")
    if actor == s["created_by"]: raise Reject("MAKER_CHECKER", "releaser must differ from creator")
    b = c.execute("SELECT * FROM bom WHERE tenant=? AND style=? AND rev=?", (t, style, rev)).fetchall()
    if not b: raise Reject("NO_BOM")
    if any(not x["verified"] for x in b): raise Reject("UNVERIFIED_WP07", "BOM materials not verified")
    c.execute("UPDATE styles SET status='RELEASED',released_by=? WHERE tenant=? AND style=? AND rev=?", (actor, t, style, rev))

@tx
def receive_lot(c, t, material, lot, qty, expiry=None, sds=False):
    try: c.execute("INSERT INTO lots(tenant,material,lot,qty,expiry,sds) VALUES(?,?,?,?,?,?)", (t, material, lot, qty, expiry, int(sds)))
    except sqlite3.IntegrityError as e: raise Reject("INVALID", str(e))

@tx
def dispose_lot(c, t, material, lot, status, actor):
    c.execute("UPDATE lots SET status=? WHERE tenant=? AND material=? AND lot=?", (status, t, material, lot))

@tx
def create_order(c, t, oid, style, rev, lines, buyer=None, required=(12,)):
    if not set(required) <= {10, 12}: raise Reject("INVALID", "only stages 10 and 12 are conditional")
    try:
        c.execute("INSERT INTO orders(tenant,id,style,rev,buyer,required) VALUES(?,?,?,?,?,?)", (t, oid, style, rev, buyer, json.dumps(sorted(required))))
        for (s, col), q in lines.items(): c.execute("INSERT INTO order_lines VALUES(?,?,?,?,?)", (t, oid, s, col, q))
    except sqlite3.IntegrityError as e: raise Reject("INVALID", str(e))

# ---- material ledgers (four, non-combinable, append-only) ----
@tx
def issue(c, t, oid, ledger, material, lot, qty, actor, on=None):
    on = on or dt.date.today().isoformat(); o = _order(c, t, oid)
    if qty <= 0: raise Reject("BAD_QTY")
    b = _one(c, "SELECT * FROM bom WHERE tenant=? AND style=? AND rev=? AND material=?", t, o["style"], o["rev"], material)
    if not b: raise Reject("NOT_ON_BOM", material)
    if ledger != b["ctype"]: raise Reject("LEDGER_MISMATCH", f"{material} belongs to the {b['ctype']} ledger, not {ledger}")
    _need(o, LEDGER_MIN[ledger])
    l = _one(c, "SELECT * FROM lots WHERE tenant=? AND material=? AND lot=?", t, material, lot)
    if not l: raise Reject("NOT_FOUND", f"lot {lot}")
    if l["status"] != "ACCEPTED": raise Reject("LOT_NOT_ACCEPTED", l["status"])
    if ledger == "CHEMICAL" and (not l["sds"] or not l["expiry"] or l["expiry"] < on): raise Reject("CHEMICAL_CONTROL", "SDS on file and unexpired lot required")
    if _bal(c, t, material, lot) < qty - 1e-9: raise Reject("INSUFFICIENT_STOCK")
    if _net(c, t, oid, ledger, material) + qty > b["per_unit"] * _total(c, t, oid) + 1e-9: raise Reject("OVER_ISSUE", "exceeds BOM requirement")
    cur = c.execute("INSERT INTO ledger(tenant,ledger,ord,material,lot,delta,kind,actor) VALUES(?,?,?,?,?,?,?,?)", (t, ledger, oid, material, lot, qty, "ISSUE", actor))
    _ev(c, t, oid, "ISSUE", {"ledger": ledger, "material": material, "lot": lot, "qty": qty}, actor); return cur.lastrowid

@tx
def return_material(c, t, oid, ledger, material, lot, qty, reason, actor):
    _order(c, t, oid)
    if not reason: raise Reject("REASON_REQUIRED")
    n = _one(c, "SELECT COALESCE(SUM(delta),0) FROM ledger WHERE tenant=? AND ord=? AND ledger=? AND material=? AND lot=?", t, oid, ledger, material, lot)[0]
    if qty <= 0 or qty > n + 1e-9: raise Reject("OVER_RETURN")
    cur = c.execute("INSERT INTO ledger(tenant,ledger,ord,material,lot,delta,kind,reason,actor) VALUES(?,?,?,?,?,?,?,?,?)", (t, ledger, oid, material, lot, -qty, "RETURN", reason, actor)); return cur.lastrowid

@tx
def reverse_entry(c, t, lid, reason, actor):
    r = _one(c, "SELECT * FROM ledger WHERE tenant=? AND id=?", t, lid)
    if not r: raise Reject("NOT_FOUND", "ledger entry")
    if not reason: raise Reject("REASON_REQUIRED")
    if r["kind"] == "REVERSAL": raise Reject("CANNOT_REVERSE_REVERSAL")
    try: cur = c.execute("INSERT INTO ledger(tenant,ledger,ord,material,lot,delta,kind,reverses,reason,actor) VALUES(?,?,?,?,?,?,?,?,?,?)", (t, r["ledger"], r["ord"], r["material"], r["lot"], -r["delta"], "REVERSAL", lid, reason, actor))
    except sqlite3.IntegrityError: raise Reject("ALREADY_REVERSED")
    return cur.lastrowid

# ---- marker, cutting, bundles ----
@tx
def approve_marker(c, t, oid, checksum, actor):
    o = _order(c, t, oid); _need(o, 5)
    c.execute("UPDATE orders SET marker=? WHERE tenant=? AND id=?", (checksum, t, oid))

@tx
def cut_bundles(c, t, oid, bundles, actor):
    o = _order(c, t, oid); _need(o, 6)
    if _net(c, t, oid, "FABRIC") <= 0: raise Reject("NO_FABRIC_ISSUE")
    for bid, s, col, q in bundles:
        ol = _one(c, "SELECT qty FROM order_lines WHERE tenant=? AND ord=? AND size=? AND colour=?", t, oid, s, col)
        if not ol: raise Reject("BAD_SIZE_COLOUR", f"{s}/{col}")
        cut = _one(c, "SELECT COALESCE(SUM(qty),0) FROM bundles WHERE tenant=? AND ord=? AND size=? AND colour=?", t, oid, s, col)[0]
        if q <= 0 or cut + q > ol["qty"]: raise Reject("OVER_CUT", f"{s}/{col}")
        try: c.execute("INSERT INTO bundles(tenant,id,ord,size,colour,qty) VALUES(?,?,?,?,?,?)", (t, bid, oid, s, col, q))
        except sqlite3.IntegrityError: raise Reject("DUPLICATE_BUNDLE", bid)
        _ev(c, t, oid, "CUT", {"bundle": bid, "size": s, "colour": col, "qty": q}, actor)

# ---- quality (idempotent scan events, independent re-inspection) ----
@tx
def inspect(c, t, bid, good, rework, reject, key, actor):
    fp = _fp("I", bid, good, rework, reject); r = _idem(c, t, key, fp)
    if r: return r
    b = _bundle(c, t, bid); o = _order(c, t, b["ord"]); _need(o, 12)
    if b["inspected"]: raise Reject("ALREADY_INSPECTED")
    if min(good, rework, reject) < 0 or good + rework + reject != b["qty"]: raise Reject("QTY_MISMATCH")
    c.execute("UPDATE bundles SET good=?,rework=?,reject=?,inspected=1,inspector=? WHERE tenant=? AND id=?", (good, rework, reject, actor, t, bid))
    _ev(c, t, b["ord"], "INSPECT", {"bundle": bid, "good": good, "rework": rework, "reject": reject}, actor)
    return _done(c, t, key, fp, {"bundle": bid, "good": good, "rework": rework, "reject": reject})

@tx
def reinspect(c, t, bid, good, rework, reject, key, actor):
    fp = _fp("R", bid, good, rework, reject); r = _idem(c, t, key, fp)
    if r: return r
    b = _bundle(c, t, bid); o = _order(c, t, b["ord"]); _need(o, 12)
    if not b["inspected"] or b["rework"] == 0: raise Reject("NOTHING_TO_REINSPECT")
    if actor == b["inspector"]: raise Reject("INDEPENDENCE", "re-inspector must differ from inspector")
    if min(good, rework, reject) < 0 or good + rework + reject != b["rework"]: raise Reject("QTY_MISMATCH")
    c.execute("UPDATE bundles SET good=good+?,rework=?,reject=reject+?,inspector=? WHERE tenant=? AND id=?", (good, rework, reject, actor, t, bid))
    _ev(c, t, b["ord"], "REINSPECT", {"bundle": bid, "good": good, "rework": rework, "reject": reject}, actor)
    return _done(c, t, key, fp, {"bundle": bid, "good": good, "rework": rework, "reject": reject})

@tx
def record_work(c, t, oid, stage, note, actor):  # sewing(11), finishing(15), conditional processes(10,12), customer feedback(19)
    if stage not in (10, 11, 12, 15, 19): raise Reject("BAD_STAGE")
    o = _order(c, t, oid)
    if stage in (10, 12) and stage not in json.loads(o["required"]): raise Reject("NOT_REQUIRED", f"stage {stage} is not on this order's route")
    if o["stage"] != stage - 1: raise Reject("ROUTE", f"order at {o['stage']}")
    _ev(c, t, oid, f"WORK:{stage}", {"note": note}, actor)

# ---- packing, buyer sampling plan (no default), FG receipt ----
@tx
def pack(c, t, oid, carton, lines, key, actor):
    fp = _fp("P", oid, carton, lines); r = _idem(c, t, key, fp)
    if r: return r
    o = _order(c, t, oid); _need(o, 15)
    for s, col, q in lines:
        g = _one(c, "SELECT COALESCE(SUM(good),0) FROM bundles WHERE tenant=? AND ord=? AND size=? AND colour=?", t, oid, s, col)[0]
        p = _one(c, "SELECT COALESCE(SUM(qty),0) FROM cartons WHERE tenant=? AND ord=? AND size=? AND colour=?", t, oid, s, col)[0]
        if q <= 0 or p + q > g: raise Reject("OVER_PACK", f"{s}/{col}: only accepted-good units may be packed")
        try: c.execute("INSERT INTO cartons VALUES(?,?,?,?,?,?)", (t, carton, oid, s, col, q))
        except sqlite3.IntegrityError: raise Reject("DUPLICATE_CARTON", carton)
    _ev(c, t, oid, "PACK", {"carton": carton, "lines": lines}, actor)
    return _done(c, t, key, fp, {"carton": carton})

@tx
def set_plan(c, t, buyer, ver, lot_min, lot_max, sample, ac, re, actor):
    if not (0 <= ac and re == ac + 1 and sample >= re and 0 < lot_min <= lot_max): raise Reject("PLAN_INVALID")
    try: c.execute("INSERT INTO plans(tenant,buyer,ver,lot_min,lot_max,sample,ac,re,created_by) VALUES(?,?,?,?,?,?,?,?,?)", (t, buyer, ver, lot_min, lot_max, sample, ac, re, actor))
    except sqlite3.IntegrityError: raise Reject("DUPLICATE")

@tx
def approve_plan(c, t, buyer, ver, actor):
    p = _one(c, "SELECT * FROM plans WHERE tenant=? AND buyer=? AND ver=?", t, buyer, ver)
    if not p: raise Reject("NOT_FOUND", "plan")
    if actor == p["created_by"]: raise Reject("MAKER_CHECKER")
    c.execute("UPDATE plans SET approved_by=? WHERE tenant=? AND buyer=? AND ver=?", (actor, t, buyer, ver))

@tx
def final_audit(c, t, oid, defects, actor):
    o = _order(c, t, oid); _need(o, 16)
    if not o["buyer"]: raise Reject("NO_BUYER")
    lot = _one(c, "SELECT COALESCE(SUM(qty),0) FROM cartons WHERE tenant=? AND ord=?", t, oid)[0]
    p = _one(c, "SELECT * FROM plans WHERE tenant=? AND buyer=? AND approved_by IS NOT NULL AND lot_min<=? AND lot_max>=? ORDER BY ver DESC", t, o["buyer"], lot, lot)
    if not p: raise Reject("NO_SAMPLING_PLAN", "no approved buyer plan covers this lot size; no default AQL is permitted")
    if not 0 <= defects <= p["sample"]: raise Reject("BAD_QTY")
    res = "PASS" if defects <= p["ac"] else "FAIL"
    try: c.execute("INSERT INTO audits VALUES(?,?,?,?,?,?,?,?)", (t, oid, p["ver"], lot, p["sample"], defects, res, actor))
    except sqlite3.IntegrityError: raise Reject("ALREADY_AUDITED")
    _ev(c, t, oid, "AUDIT", {"result": res, "defects": defects, "plan": p["ver"]}, actor); return res

@tx
def receive_fg(c, t, oid, key, actor):
    fp = _fp("FG", oid); r = _idem(c, t, key, fp)
    if r: return r
    o = _order(c, t, oid); _need(o, 17)
    a = _one(c, "SELECT result FROM audits WHERE tenant=? AND ord=?", t, oid)
    if not a or a["result"] != "PASS": raise Reject("AUDIT_NOT_PASSED")
    _g13(c, t, o); _g14(c, t, o); _g16(c, t, o)
    qty = _one(c, "SELECT SUM(qty) FROM cartons WHERE tenant=? AND ord=?", t, oid)[0]
    rej = _one(c, "SELECT SUM(reject) FROM bundles WHERE tenant=? AND ord=?", t, oid)[0]
    try: c.execute("INSERT INTO fg_receipts VALUES(?,?,?,?)", (t, oid, qty, actor))
    except sqlite3.IntegrityError: raise Reject("ALREADY_RECEIVED", "finished goods are received exactly once")
    c.execute("INSERT INTO outbox VALUES(?,?,?,?)", (t, f"FG:{oid}", "fg.received", json.dumps({"order": oid, "qty": qty, "reject": rej})))
    _ev(c, t, oid, "FG_RECEIPT", {"qty": qty}, actor); return _done(c, t, key, fp, {"order": oid, "qty": qty})

# ---- planning calculation (theoretical only) ----
def sam_target(net_minutes, efficiency, sam, approved):
    if not approved: raise Reject("SAM_NOT_APPROVED", "needs effective-dated, IE-approved SAM")
    if not (0 < efficiency <= 1) or sam <= 0 or net_minutes < 0: raise Reject("BAD_INPUT")
    return net_minutes * efficiency / sam   # theoretical starting point, not an executable target

# ---- 19-stage route guards ----
def _bom(c, t, o):
    req = json.loads(o["required"])
    return [b for b in c.execute("SELECT * FROM bom WHERE tenant=? AND style=? AND rev=?", (t, o["style"], o["rev"])) if b["ctype"] != "CHEMICAL" or 12 in req]
def _g2(c, t, o):
    if _one(c, "SELECT status FROM styles WHERE tenant=? AND style=? AND rev=?", t, o["style"], o["rev"])["status"] != "RELEASED": raise Reject("TECH_NOT_RELEASED")
def _g3(c, t, o):
    for b in _bom(c, t, o):
        if not _one(c, "SELECT 1 FROM lots WHERE tenant=? AND material=? AND status='ACCEPTED'", t, b["material"]): raise Reject("NO_ACCEPTED_LOT", b["material"])
def _g4(c, t, o):
    tot = _total(c, t, o["id"])
    for b in _bom(c, t, o):
        av = _one(c, "SELECT COALESCE(SUM(l.qty-COALESCE((SELECT SUM(delta) FROM ledger g WHERE g.tenant=l.tenant AND g.material=l.material AND g.lot=l.lot),0)),0) FROM lots l WHERE l.tenant=? AND l.material=? AND l.status='ACCEPTED'", t, b["material"])[0]
        if av < b["per_unit"] * tot - 1e-9: raise Reject("SHORTAGE", b["material"])
def _g5(c, t, o):
    if _net(c, t, o["id"], "FABRIC") <= 0: raise Reject("NO_FABRIC_ISSUE")
def _g6(c, t, o):
    if not o["marker"]: raise Reject("NO_MARKER")
def _g7(c, t, o):
    if _one(c, "SELECT COALESCE(SUM(qty),0) FROM bundles WHERE tenant=? AND ord=?", t, o["id"])[0] <= 0: raise Reject("NO_CUT")
def _g8(c, t, o):
    for l in c.execute("SELECT * FROM order_lines WHERE tenant=? AND ord=?", (t, o["id"])).fetchall():
        if _one(c, "SELECT COALESCE(SUM(qty),0) FROM bundles WHERE tenant=? AND ord=? AND size=? AND colour=?", t, o["id"], l["size"], l["colour"])[0] != l["qty"]: raise Reject("RECON_MISMATCH", f"{l['size']}/{l['colour']}")
def _g9(c, t, o):
    for b in _bom(c, t, o):
        if b["ctype"] == "TRIM" and _net(c, t, o["id"], "TRIM", b["material"]) < b["per_unit"] * _total(c, t, o["id"]) - 1e-9: raise Reject("TRIM_INCOMPLETE", b["material"])
def _work(n):
    def g(c, t, o):
        if not _one(c, "SELECT 1 FROM events WHERE tenant=? AND ord=? AND kind=?", t, o["id"], f"WORK:{n}"): raise Reject("NO_WORK_RECORD", f"stage {n}")
        if n == 19 and not _one(c, "SELECT 1 FROM fg_receipts WHERE tenant=? AND ord=?", t, o["id"]): raise Reject("NO_FG_RECEIPT")
    return g
def _g13(c, t, o):
    r = _one(c, "SELECT COUNT(*) n, SUM(inspected=0) u FROM bundles WHERE tenant=? AND ord=?", t, o["id"])
    if r["n"] == 0 or r["u"]: raise Reject("UNINSPECTED")
def _g14(c, t, o):
    if _one(c, "SELECT COALESCE(SUM(rework),0) FROM bundles WHERE tenant=? AND ord=?", t, o["id"])[0] > 0: raise Reject("REWORK_OPEN")
def _g16(c, t, o):
    p = _one(c, "SELECT COALESCE(SUM(qty),0) FROM cartons WHERE tenant=? AND ord=?", t, o["id"])[0]
    g = _one(c, "SELECT COALESCE(SUM(good),0) FROM bundles WHERE tenant=? AND ord=?", t, o["id"])[0]
    if p <= 0 or p != g: raise Reject("PACK_MISMATCH", f"packed {p} vs accepted {g}")
def _g17(c, t, o):
    a = _one(c, "SELECT result FROM audits WHERE tenant=? AND ord=?", t, o["id"])
    if not a or a["result"] != "PASS": raise Reject("AUDIT_NOT_PASSED")
def _g18(c, t, o):
    if not _one(c, "SELECT 1 FROM fg_receipts WHERE tenant=? AND ord=?", t, o["id"]): raise Reject("NO_FG_RECEIPT")
GUARDS = {1: lambda c, t, o: None, 2: _g2, 3: _g3, 4: _g4, 5: _g5, 6: _g6, 7: _g7, 8: _g8, 9: _g9, 10: _work(10), 11: _work(11), 12: _work(12),
          13: _g13, 14: _g14, 15: _work(15), 16: _g16, 17: _g17, 18: _g18, 19: _work(19)}

@tx
def advance(c, t, oid, actor):
    o = _order(c, t, oid); n = o["stage"] + 1
    if n > 19: raise Reject("ROUTE_COMPLETE")
    name, cond = STAGES[n]
    if cond and n not in json.loads(o["required"]): kind = "SKIPPED"
    else: GUARDS[n](c, t, o); kind = "COMPLETED"
    if c.execute("UPDATE orders SET stage=? WHERE tenant=? AND id=? AND stage=?", (n, t, oid, o["stage"])).rowcount != 1: raise Reject("CONCURRENT_UPDATE")
    _ev(c, t, oid, kind, {"stage": n, "name": name}, actor); return n
