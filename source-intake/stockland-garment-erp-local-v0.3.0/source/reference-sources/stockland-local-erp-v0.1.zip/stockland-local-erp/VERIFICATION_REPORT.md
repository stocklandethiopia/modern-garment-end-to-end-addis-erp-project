# Local Reference Runtime — Verification Report
**Result: PASS** · 2026-11-24T09:35:38+00:00 · Python 3.12.3 · SQLite 3.45.1

## Actually run
- 16 unit/integration tests: 0 failures, 0 errors.
- Full 19-stage replay for one order (100 cut, 99 good FG received, 1 reject; stage 10 skipped by route): final stage 19, FG receipt 99, outbox events 1.
- Ledger nets (fabric/trim/chemical/packaging): {'FABRIC': 120.0, 'TRIM': 600.0, 'CHEMICAL': 5.0, 'PACKAGING': 100.0}

## Controls covered by tests
route-order enforcement · technical-release gate · UNVERIFIED_WP07 gate · maker-checker (release, sampling plan) · four non-combinable append-only ledgers with single reversal · lot acceptance/stock/over-issue · chemical SDS+expiry · cutting/bundle reconciliation · idempotent scan events + key-reuse rejection · independent re-inspection · pack ≤ accepted-good · no default AQL plan, failed audit blocks · FG receipt exactly once + outbox dedupe · cross-tenant isolation · SAM planning calc requires approval.

## NOT verified (this is a stand-in, not the canonical stack)
Laravel 13 / PHP 8.5 · Angular 22 · PostgreSQL 18 and database RLS · real concurrency (SQLite single-writer) · HTTP API, UI, auth · bundle split/merge · reservations · costing/GL · WMS beyond FG receipt · POS/retail/distribution · security, performance, backup/restore · GitHub CI at an exact SHA.

## File manifest (SHA-256)
- `README.md` f4f5b4b19a270d0e2f47049e23dd0c2cc444a81a8e90750338cf1a1d18a9b75a
- `install.py` b08b8e930f019dc72162992fcd335e7b3e43a5061453f29b3eaf7c56106323b1
- `stockland_local/__init__.py` a813d51ae82dbe56a9885526c4e85955c6c35546d784fc860278f8c4bd393219
- `stockland_local/engine.py` f7b3997f9fd87bb2e04841fa46c4a458cb6752fdeccf5e4422f2f0909201f379
- `stockland_local/scenario.py` e30bed48a5a1a72483ff3dad1bd825cfa0c0dd78076bc2f2128a319d336a0c4a
- `tests/__init__.py` e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
- `tests/test_engine.py` 550d6b3637a23ed6c2ff8bf58c1bb297c194ca7b6035bf998b22e301ceb776fc
