#!/usr/bin/env python3
"""One-command local install + verification. Stdlib only: python3 install.py [--data DIR] [--reset]"""
import argparse, datetime, hashlib, io, json, os, platform, sqlite3, sys, unittest
ROOT = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, ROOT)
SKIP = {"__pycache__", "data", "VERIFICATION_REPORT.md", "verification.json"}

def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def manifest():
    out = {}
    for d, ds, fs in os.walk(ROOT):
        ds[:] = sorted(x for x in ds if x not in SKIP)
        for f in sorted(fs):
            if f not in SKIP and not f.endswith((".pyc", ".zip")): p = os.path.join(d, f); out[os.path.relpath(p, ROOT)] = sha(p)
    return out

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--data", default=os.path.join(ROOT, "data")); ap.add_argument("--reset", action="store_true"); a = ap.parse_args()
    if sys.version_info < (3, 10) or sqlite3.sqlite_version_info < (3, 35): sys.exit("FAIL preflight: need Python>=3.10 and SQLite>=3.35")
    os.makedirs(a.data, exist_ok=True); db = os.path.join(a.data, "stockland_local.db")
    if os.path.exists(db):
        if not a.reset: sys.exit(f"{db} exists; re-run with --reset to rebuild")
        os.remove(db)
    from stockland_local import engine as E, scenario as S
    print("[1/3] running test suite ...")
    buf = io.StringIO(); r = unittest.TextTestRunner(stream=buf, verbosity=0).run(unittest.defaultTestLoader.discover(os.path.join(ROOT, "tests"), top_level_dir=ROOT))
    ok = r.wasSuccessful(); print(f"      {r.testsRun} tests, {len(r.failures)} failures, {len(r.errors)} errors"); 
    if not ok: print(buf.getvalue())
    print("[2/3] initialising database and replaying the 19-stage demo ...")
    c = E.connect(db); S.setup(c, "demo-tenant"); S.drive(c, "demo-tenant", 19)
    route = [(json.loads(e["detail"])["stage"], e["kind"], json.loads(e["detail"])["name"]) for e in c.execute("SELECT kind,detail FROM events WHERE kind IN('COMPLETED','SKIPPED') ORDER BY id")]
    for n, k, nm in route: print(f"      stage {n:>2} {k:<9} {nm}")
    q = lambda s: c.execute(s).fetchone()[0]
    demo = {"final_stage": q("select stage from orders"), "fg_received": q("select qty from fg_receipts"), "rejected": q("select sum(reject) from bundles"),
            "ledger_net": {l: round(q(f"select sum(delta) from ledger where ledger='{l}'"), 6) for l in E.LEDGER_MIN}, "outbox_events": q("select count(*) from outbox"), "audit_events": q("select count(*) from events")}
    print("      ", demo); ok = ok and demo["final_stage"] == 19 and demo["fg_received"] == 99
    rep = {"generated": datetime.datetime.now().astimezone().isoformat(timespec="seconds"), "python": platform.python_version(), "sqlite": sqlite3.sqlite_version,
           "tests": {"run": r.testsRun, "failures": len(r.failures), "errors": len(r.errors)}, "demo": demo, "result": "PASS" if ok else "FAIL", "manifest_sha256": manifest()}
    json.dump(rep, open(os.path.join(ROOT, "verification.json"), "w"), indent=1)
    md = f"""# Local Reference Runtime — Verification Report
**Result: {rep['result']}** · {rep['generated']} · Python {rep['python']} · SQLite {rep['sqlite']}

## Actually run
- {r.testsRun} unit/integration tests: {len(r.failures)} failures, {len(r.errors)} errors.
- Full 19-stage replay for one order (100 cut, 99 good FG received, 1 reject; stage 10 skipped by route): final stage {demo['final_stage']}, FG receipt {demo['fg_received']}, outbox events {demo['outbox_events']}.
- Ledger nets (fabric/trim/chemical/packaging): {demo['ledger_net']}

## Controls covered by tests
route-order enforcement · technical-release gate · UNVERIFIED_WP07 gate · maker-checker (release, sampling plan) · four non-combinable append-only ledgers with single reversal · lot acceptance/stock/over-issue · chemical SDS+expiry · cutting/bundle reconciliation · idempotent scan events + key-reuse rejection · independent re-inspection · pack ≤ accepted-good · no default AQL plan, failed audit blocks · FG receipt exactly once + outbox dedupe · cross-tenant isolation · SAM planning calc requires approval.

## NOT verified (this is a stand-in, not the canonical stack)
Laravel 13 / PHP 8.5 · Angular 22 · PostgreSQL 18 and database RLS · real concurrency (SQLite single-writer) · HTTP API, UI, auth · bundle split/merge · reservations · costing/GL · WMS beyond FG receipt · POS/retail/distribution · security, performance, backup/restore · GitHub CI at an exact SHA.

## File manifest (SHA-256)
""" + "\n".join(f"- `{k}` {v}" for k, v in rep["manifest_sha256"].items()) + "\n"
    open(os.path.join(ROOT, "VERIFICATION_REPORT.md"), "w").write(md)
    print(f"[3/3] wrote VERIFICATION_REPORT.md and verification.json -> {rep['result']}"); sys.exit(0 if ok else 1)
main()
