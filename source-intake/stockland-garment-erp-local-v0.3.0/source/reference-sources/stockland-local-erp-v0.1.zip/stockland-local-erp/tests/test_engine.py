import unittest, sqlite3
from stockland_local import engine as E, scenario as S

def world(upto=0, t="A", **kw):
    c = E.connect(":memory:"); S.setup(c, t, **kw); S.drive(c, t, upto); return c

class T(unittest.TestCase):
    def rej(self, code, f, *a, **k):
        with self.assertRaises(E.Reject) as r: f(*a, **k)
        self.assertEqual(r.exception.code, code)
    def scalar(self, c, sql): return c.execute(sql).fetchone()[0]

    def test_e2e_full_19_stage_route(self):
        c = world(19); self.assertEqual(E._order(c, "A", "ORD-1")["stage"], 19)
        self.assertEqual(self.scalar(c, "select qty from fg_receipts"), 99)          # 100 cut - 1 reject
        self.assertEqual(self.scalar(c, "select count(*) from outbox"), 1)
        self.assertEqual(self.scalar(c, "select count(*) from events where kind='SKIPPED'"), 1)  # stage 10 not on route
        for led, q in (("FABRIC", 120), ("TRIM", 600), ("CHEMICAL", 5), ("PACKAGING", 100)): self.assertAlmostEqual(E._net(c, "A", "ORD-1", led), q)

    def test_release_gate_wp07_and_maker_checker(self):
        c = E.connect(); E.add_tenant(c, "A"); E.create_style(c, "A", "S1", 1, [("FAB", "FABRIC", 1.0)], "designer")
        self.rej("UNVERIFIED_WP07", E.release_style, c, "A", "S1", 1, "approver")
        E.verify_material(c, "A", "S1", 1, "FAB", "stub")
        self.rej("MAKER_CHECKER", E.release_style, c, "A", "S1", 1, "designer")
        E.release_style(c, "A", "S1", 1, "approver")

    def test_unreleased_technical_revision_blocks_stage2(self):
        c = E.connect(); E.add_tenant(c, "A"); E.create_style(c, "A", "S1", 1, [("FAB", "FABRIC", 1.0)], "d")
        E.create_order(c, "A", "O1", "S1", 1, {("S", "X"): 10}); E.advance(c, "A", "O1", "p")
        self.rej("TECH_NOT_RELEASED", E.advance, c, "A", "O1", "p")

    def test_route_order_is_enforced(self):
        c = world(4)
        self.rej("ROUTE", E.cut_bundles, c, "A", "ORD-1", [("X", "S", "BLK", 1)], "u")
        self.rej("ROUTE", E.issue, c, "A", "ORD-1", "TRIM", "BTN", "T1", 1, "u", S.ON)

    def test_four_ledgers_never_combine_and_issue_controls(self):
        c = world(4)
        self.rej("LEDGER_MISMATCH", E.issue, c, "A", "ORD-1", "FABRIC", "BTN", "T1", 1, "u", S.ON)
        self.rej("NOT_ON_BOM", E.issue, c, "A", "ORD-1", "FABRIC", "GHOST", "L", 1, "u", S.ON)
        E.receive_lot(c, "A", "JERSEY", "F2", 50)
        self.rej("LOT_NOT_ACCEPTED", E.issue, c, "A", "ORD-1", "FABRIC", "JERSEY", "F2", 1, "u", S.ON)
        self.rej("OVER_ISSUE", E.issue, c, "A", "ORD-1", "FABRIC", "JERSEY", "F1", 121, "u", S.ON)

    def test_chemical_requires_sds_and_unexpired_lot(self):
        c = world(11)
        for lot, exp, sds in (("C2", "2027-06-30", False), ("C3", "2026-01-01", True)):
            E.receive_lot(c, "A", "WASH", lot, 5, expiry=exp, sds=sds); E.dispose_lot(c, "A", "WASH", lot, "ACCEPTED", "qc")
            self.rej("CHEMICAL_CONTROL", E.issue, c, "A", "ORD-1", "CHEMICAL", "WASH", lot, 1, "u", S.ON)

    def test_ledger_append_only_single_reversal(self):
        c = world(5); lid = self.scalar(c, "select min(id) from ledger")
        with self.assertRaises(sqlite3.DatabaseError): c.execute("UPDATE ledger SET delta=1")
        with self.assertRaises(sqlite3.DatabaseError): c.execute("DELETE FROM ledger")
        self.rej("REASON_REQUIRED", E.reverse_entry, c, "A", lid, "", "u")
        rid = E.reverse_entry(c, "A", lid, "wrong roll", "u"); self.assertEqual(E._net(c, "A", "ORD-1", "FABRIC"), 0)
        self.rej("ALREADY_REVERSED", E.reverse_entry, c, "A", lid, "again", "u")
        self.rej("CANNOT_REVERSE_REVERSAL", E.reverse_entry, c, "A", rid, "x", "u")

    def test_cut_over_and_reconciliation_gate(self):
        c = world(7); self.rej("OVER_CUT", E.cut_bundles, c, "A", "ORD-1", [("B9", "S", "BLK", 1)], "u")
        c = world(6); E.cut_bundles(c, "A", "ORD-1", [("B1", "S", "BLK", 30), ("B2", "M", "BLK", 40)], "u")
        E.advance(c, "A", "ORD-1", "p"); self.rej("RECON_MISMATCH", E.advance, c, "A", "ORD-1", "p")

    def test_idempotent_scan_key_reuse_and_independent_reinspection(self):
        c = world(12); a = E.inspect(c, "A", "B2", 38, 2, 0, "k1", "qa1")
        self.assertTrue(E.inspect(c, "A", "B2", 38, 2, 0, "k1", "qa1")["replayed"])
        self.assertEqual(self.scalar(c, "select good from bundles where id='B2'"), 38)
        self.rej("KEY_REUSE", E.inspect, c, "A", "B2", 40, 0, 0, "k1", "qa1")
        self.rej("QTY_MISMATCH", E.inspect, c, "A", "B3", 1, 1, 1, "k3", "qa1")
        self.rej("INDEPENDENCE", E.reinspect, c, "A", "B2", 2, 0, 0, "k2", "qa1")
        E.reinspect(c, "A", "B2", 2, 0, 0, "k2", "qa2"); self.assertEqual(self.scalar(c, "select good from bundles where id='B2'"), 40)

    def test_open_rework_blocks_stage14(self):
        c = world(13); self.rej("REWORK_OPEN", E.advance, c, "A", "ORD-1", "p")

    def test_cannot_pack_more_than_accepted_good(self):
        c = world(15); self.rej("OVER_PACK", E.pack, c, "A", "ORD-1", "CTN1", [("S", "BLK", 31)], "pk", "u")

    def test_no_default_sampling_plan_and_failed_audit_blocks(self):
        c = world(16); self.rej("NO_SAMPLING_PLAN", E.final_audit, c, "A", "ORD-1", 0, "aud")
        E.set_plan(c, "A", "BUYER-X", 1, 50, 150, 13, 1, 2, "p"); self.rej("MAKER_CHECKER", E.approve_plan, c, "A", "BUYER-X", 1, "p")
        self.rej("NO_SAMPLING_PLAN", E.final_audit, c, "A", "ORD-1", 0, "aud")   # unapproved plan is not usable
        E.approve_plan(c, "A", "BUYER-X", 1, "q"); self.assertEqual(E.final_audit(c, "A", "ORD-1", 2, "aud"), "FAIL")
        self.rej("AUDIT_NOT_PASSED", E.advance, c, "A", "ORD-1", "p")

    def test_fg_receipt_exactly_once(self):
        c = world(18); self.assertTrue(E.receive_fg(c, "A", "ORD-1", "fg-1", "w")["replayed"])
        self.rej("ALREADY_RECEIVED", E.receive_fg, c, "A", "ORD-1", "fg-2", "w")
        self.assertEqual(self.scalar(c, "select count(*) from fg_receipts"), 1); self.assertEqual(self.scalar(c, "select count(*) from outbox"), 1)

    def test_cross_tenant_isolation(self):
        c = world(5); E.add_tenant(c, "B")
        self.rej("NOT_FOUND", E.advance, c, "B", "ORD-1", "x")
        self.rej("NOT_FOUND", E.issue, c, "B", "ORD-1", "FABRIC", "JERSEY", "F1", 1, "x", S.ON)
        self.assertEqual(E._net(c, "B", "ORD-1", "FABRIC"), 0)

    def test_conditional_stage_rules(self):
        c = world(9); self.rej("NOT_REQUIRED", E.record_work, c, "A", "ORD-1", 10, "n", "u")
        c = world(9, required=(10, 12)); self.rej("NO_WORK_RECORD", E.advance, c, "A", "ORD-1", "p")
        E.record_work(c, "A", "ORD-1", 10, "print", "u"); self.assertEqual(E.advance(c, "A", "ORD-1", "p"), 10)

    def test_sam_target_is_planning_only(self):
        self.assertAlmostEqual(E.sam_target(48000, 0.6, 12, True), 2400)
        self.rej("SAM_NOT_APPROVED", E.sam_target, 48000, 0.6, 12, False)

if __name__ == "__main__": unittest.main()
